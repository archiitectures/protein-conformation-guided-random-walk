# Endpoint Pair QC: 1V4T_A__1V4S_A

Status: **manual_review**

- Sequence identity: 1.0000
- Aligned coverage: 0.9912
- Common C-alpha atoms: 423
- Aligned C-alpha RMSD: 9.503988991535012
- Candidate selection score: 0.0000
- BioEmu sequence source: canonical

## Warnings

- Endpoint chain lengths differ by 4 residues
- Ligand, metal, or nucleotide occupancy differs between endpoints

## Rejection Reasons

- None

## Sequence Selection Warnings

- None

## Scientific Caveat

Multiple experimental structures do not prove a direct transition pathway. Equilibrium
accessibility does not imply kinetic connectivity. Ligands, mutations, truncations,
oligomeric changes, and missing residues can all produce structural differences. This
report identifies a candidate endpoint pair plus QC evidence, not ground truth.
