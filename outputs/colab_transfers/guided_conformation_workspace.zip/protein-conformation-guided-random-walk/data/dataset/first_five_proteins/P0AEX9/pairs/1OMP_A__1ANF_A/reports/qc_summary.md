# Endpoint Pair QC: 1OMP_A__1ANF_A

Status: **manual_review**

- Sequence identity: 1.0000
- Aligned coverage: 1.0000
- Common C-alpha atoms: 370
- Aligned C-alpha RMSD: 3.774462483026865
- Candidate selection score: 0.0000
- BioEmu sequence source: canonical

## Warnings

- Source organisms differ

## Rejection Reasons

- None

## Sequence Selection Warnings

- None

## Scientific Caveat

Multiple experimental structures do not prove a direct transition pathway. Equilibrium
accessibility does not imply kinetic connectivity. Ligands, mutations, truncations,
oligomeric changes, and missing residues can all produce structural differences. This
report identifies a candidate endpoint pair plus QC evidence, not ground truth.
