# Protein Conformation Guided-Random Walk

This repository contains an initial research prototype for building candidate
conformational transition graphs between two endpoint protein structures.

> This prototype constructs candidate conformational transition graphs between two endpoint protein structures. Generated conformations are treated as candidate nodes, and edge costs are heuristic transition-plausibility scores. The resulting shortest path is a proposed structural path, not a validated physical transition pathway.

## What It Does

- Represents protein conformations as C-alpha coordinate nodes.
- Generates candidate nodes recursively from endpoint-seeded frontier structures
  using a dummy perturbation generator.
- Scores edges between conformations with RMSD or distance-histogram costs.
- Builds a weighted NetworkX graph over endpoints and generated conformations.
- Finds a lowest-cost path between endpoint A and endpoint B.
- Saves a JSON path summary, a graph PNG, a best-path morph GIF, and generated
  PDB-like node files.

## What It Does Not Claim

- It does not prove kinetic connectivity between generated conformations.
- It does not estimate MSM transition probabilities, stationary distributions, MFPTs, or free energies.
- It does not claim the shortest graph path is the true physical transition pathway.
- BioEmu support is limited to a Colab-facing sampling runner that writes
  generated structures as portable candidate-node bundles.

Generated plausible structures are candidate graph nodes only. Equilibrium-like
samples or model-generated conformations do not automatically determine
transition dynamics.

## Current Abstractions

- `ConformationNode` is the central data object. It stores a unique node ID,
  source label, optional metadata, optional source path, and C-alpha coordinates
  with shape `(L, 3)`.
- `NodeGenerator` defines how candidate nodes are proposed from an endpoint.
  The dummy generator adds Gaussian noise to C-alpha coordinates and rejects
  samples that fail lightweight validity checks.
- `EdgeScorer` defines graph edge costs. `RMSDScorer` uses Kabsch-aligned
  C-alpha RMSD. `DistanceHistogramScorer` compares global pairwise C-alpha
  distance histograms.
- `validity.py` provides coarse C-alpha checks for finite coordinates,
  consecutive C-alpha bond-distance ranges, and non-neighbor C-alpha
  clash-like overlaps.
- `build_conformation_graph` creates a NetworkX weighted graph. Edge weights are
  scorer costs plus an additive validity penalty.
- `find_shortest_path` uses Dijkstra shortest path over graph edge weights. Its
  optional `beta` parameter only reports unnormalized `exp(-beta * weight)`
  diagnostics; it does not change the path objective.

The clash filter is intentionally C-alpha-only because the current data model
does not store full atom coordinates. It helps reject severe coordinate overlaps
from Gaussian perturbations, but it is not a full atom-atom steric validation.
Full clash detection will require full-atom structures or atom reconstruction in
a later version.

## Setup

Using `uv`:

```bash
uv sync --extra test --extra notebook
```

Then run commands through the managed environment:

```bash
uv run pytest
uv run python scripts/run_demo.py
uv run python scripts/run_large_synthetic_experiment.py
```

The repository includes `uv.toml`, so uv keeps its package cache in `.uv-cache`
inside the project directory. You should not need to set `UV_CACHE_DIR` manually.

The reusable model/experiment definitions for the larger synthetic test live in
`guided_conformational_path/large_synthetic.py`. The CLI script and notebook are
thin interfaces over that module.

To use the notebook interface:

```bash
uv run python -m ipykernel install --user --name guided-conformational-path --display-name "guided-conformational-path (.venv)"
```

Then open `notebooks/large_synthetic_experiment.ipynb` in Jupyter or VS Code and
select the `guided-conformational-path (.venv)` kernel.

If a notebook raises `ModuleNotFoundError` for a package such as `tqdm`, it is
using the wrong kernel. Re-run the `uv sync` command above and select the project
kernel again.

For PDB endpoint experiments, place files here:

```text
data/pdb_inputs/A.pdb
data/pdb_inputs/B.pdb
```

The notebook has a dedicated PDB-endpoint section that loads those files and
runs the same graph/path/3D-view workflow. The current PDB parser uses C-alpha
coordinates only.

PDB endpoint matching supports `matching_method="exact_then_geometric"`. The
loader first tries exact matching by chain ID, residue number, and insertion
code. If too few residue IDs overlap, it falls back to a Kabsch-aligned mutual
nearest-neighbor C-alpha match. This fallback is useful for exploratory tests
with very similar backbones, but it is heuristic and should not be treated as a
validated sequence or structural alignment.

Using standard `venv`:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[test,notebook]"
```

The project uses CPU-friendly scientific and data dependencies only. The graph
prototype uses NumPy, SciPy, NetworkX, Matplotlib, and Pillow. Experimental
dataset preparation additionally uses Gemmi, Biopython, pandas, requests, and
PyYAML. No heavyweight machine-learning framework is installed locally.

## Build an Experimental Endpoint Dataset

The `protein_conformer_dataset` package prepares candidate experimentally
observed endpoint pairs before BioEmu generation or graph analysis. It supports
explicit endpoint manifests, exact UniProt-to-PDB discovery, and PDB lists
grouped by exact UniProt mappings.

### Quick Start

Run the included adenylate kinase manifest:

```bash
uv run python scripts/build_dataset.py \
  --manifest data/input/endpoints.csv \
  --output-dir data/dataset
```

Discover structures automatically from UniProt:

```bash
uv run python scripts/build_dataset.py \
  --uniprot-ids P69441 \
  --output-dir data/dataset \
  --top-k-pairs 3 \
  --resume
```

Or use a file of accessions:

```bash
printf "P69441\nP62158\n" > data/input/uniprot_ids.txt
uv run python scripts/build_dataset.py \
  --uniprot-ids-file data/input/uniprot_ids.txt \
  --output-dir data/dataset \
  --top-k-pairs 3 \
  --resume
```

Inspect one automatic entry:

```bash
uv run python scripts/inspect_entry.py --protein-id P69441
```

Inspect the included explicit pair after building it:

```bash
uv run python scripts/inspect_entry.py \
  --protein-id adenylate_kinase \
  --pair-id 4AKE_A__1AKE_A
```

### File-By-File Python Map

Package modules:

- `protein_conformer_dataset/__init__.py`: package exports.
- `protein_conformer_dataset/alignment.py`: global sequence alignment, residue
  mapping, and Kabsch superposition.
- `protein_conformer_dataset/checkpoint.py`: resumable stage storage in
  `<output-dir>/.state/`.
- `protein_conformer_dataset/config.py`: top-level, QC, and ranking
  configuration models.
- `protein_conformer_dataset/download.py`: cached HTTP, retry policy, and mmCIF
  downloading.
- `protein_conformer_dataset/export.py`: per-pair directory export and
  dataset-level CSV/YAML tables.
- `protein_conformer_dataset/logging_utils.py`: run logger setup.
- `protein_conformer_dataset/models.py`: serializable records, residues,
  mappings, QC reports, and endpoint-pair models.
- `protein_conformer_dataset/pair_selection.py`: metadata prefiltering,
  pairwise comparison, duplicate filtering, and ranking.
- `protein_conformer_dataset/parsing.py`: Gemmi chain parsing, unresolved
  residue handling, altloc selection, and environment extraction.
- `protein_conformer_dataset/pipeline.py`: end-to-end orchestration across all
  input modes.
- `protein_conformer_dataset/quality_control.py`: accepted/manual-review/
  rejected classification logic.
- `protein_conformer_dataset/rcsb_client.py`: RCSB discovery and metadata fetch.
- `protein_conformer_dataset/sequence.py`: residue normalization and BioEmu
  sequence choice.
- `protein_conformer_dataset/sifts_client.py`: optional PDBe/SIFTS mapping
  retrieval.
- `protein_conformer_dataset/structure.py`: protein-only processed mmCIF
  writing.
- `protein_conformer_dataset/uniprot_client.py`: canonical UniProt metadata.

Dataset scripts:

- `scripts/build_dataset.py`: CLI entry point for discovery, QC, ranking,
  checkpointing, sequence choice, and export.
- `scripts/inspect_entry.py`: reads one exported manifest and prints the key QC
  evidence for manual review.

### `scripts/build_dataset.py` End-To-End Flow

1. Choose one input mode.
   Use `--manifest`, `--uniprot-ids`, `--uniprot-ids-file`, or `--pdb-ids`.

2. Build `DatasetConfig`.
   The CLI creates permissive or strict QC defaults, then applies any explicit
   threshold overrides such as minimum sequence identity or common C-alpha count.

3. Start logging and checkpointing.
   The pipeline writes `run_log.txt` and creates a fingerprinted `.state/`
   directory under the output root.

4. Resolve input metadata.
   UniProt mode fetches canonical sequence metadata and exact RCSB mappings.
   PDB mode resolves polymer entities from the supplied entries and groups them
   by exact UniProt accession. Manifest mode resolves the exact requested
   `pdb/chain` rows.

5. Bound the automatic candidate set.
   Automatic discovery keeps at most `--max-structures` structures per protein,
   preferring constructs whose sequence length best matches the canonical
   UniProt length, then better resolution.

6. Download raw mmCIF files.
   Structure downloads are cached in `data/cache` by default and can be reused
   on resumed runs.

7. Parse structures into standardized chains.
   The parser preserves unresolved positions when the entity full sequence is
   available, chooses a single C-alpha altloc, and records ligands, partner
   chains, model count, and other context metadata.

8. Align sequences, not author numbering.
   Endpoint chains are globally aligned by amino-acid sequence. Only aligned
   positions where both endpoints contain a C-alpha atom enter the matched
   coordinate arrays.

9. Run QC.
   The pipeline checks identity, coverage, common C-alpha count, length
   mismatch, resolution, mutation annotations, missing residues, experimental
   method, ligands, partners, and oligomer/context warnings.

10. Assign `accepted`, `manual_review`, or `rejected`.
   `accepted` means no hard-threshold failures and no warnings. `manual_review`
   means thresholds passed but some contextual caveat still matters.
   `rejected` means a hard QC rule failed.

11. Rank automatic candidates.
   Rejected pairs and near-duplicates are removed from automatic ranking. The
   remaining pairs are scored with a heuristic candidate score.

12. Choose the BioEmu sequence.
   The canonical UniProt sequence is selected only when both endpoints remain
   compatible with it. Otherwise the pipeline can emit a shared construct
   sequence or leave the selection empty for manual review.

13. Export pair directories and dataset tables.
   Automatic discovery exports the single best-ranked usable pair under
   `<output-dir>/<protein_id>/`. Explicit manifest rows export under
   `<output-dir>/<protein_id>/pairs/<pair_id>/`, including rejected rows so
   their evidence is preserved. Dataset-level CSVs keep all pairwise results,
   top-ranked rows, and status-specific subsets.

### Output Summary

Each exported pair directory contains:

- raw entry mmCIF files in `raw/`
- processed protein-only C-alpha mmCIF files in `processed/`
- matched and aligned NumPy arrays in `processed/`
- `common_residue_mapping.csv`
- `canonical.fasta`, `construct.fasta`, and/or `bioemu_selected.fasta` in
  `sequence/`
- endpoint metadata JSON plus QC/environment JSON in `metadata/`
- `qc_summary.md` in `reports/`
- `manifest.json` at the pair root

The output root also contains:

- `pairwise_metrics.csv`
- `dataset_manifest.csv`
- `top_candidate_pairs.csv`
- `accepted_pairs.csv`
- `manual_review_pairs.csv`
- `rejected_pairs.csv`
- `all_structures.csv`
- `run_config.yaml`
- `run_log.txt`
- `run_summary.json`

### Important Scientific and Operational Caveats

- Multiple experimental structures do not prove a direct transition pathway.
- Equilibrium accessibility does not imply kinetic connectivity.
- The candidate score is only a ranking heuristic, not a physical score.
- Ligand-bound and apo structures may represent different environments.
- Mutations, truncations, and unresolved residues can create artificial
  structural differences.
- Oligomer and partner-chain metadata are useful review signals, not definitive
  biological-assembly truth.
- `--resume` only reuses checkpoints whose input/configuration fingerprint still
  matches.
- In automatic mode, `--top-k-pairs` affects the ranked CSV outputs, but the
  current implementation exports only the single best-ranked pair directory.

See `protein_conformer_dataset/README_DETAILED.md` for the full package-level
workflow and caveats.

## Run The Demo

Run with synthetic toy endpoints:

```bash
python scripts/run_demo.py
```

Run with PDB endpoints:

```bash
python scripts/run_demo.py \
  --endpoint-a data/pdb_inputs/A.pdb \
  --endpoint-b data/pdb_inputs/B.pdb \
  --n-samples 20 \
  --scorer rmsd
```

Outputs are written to:

- `outputs/path_summary.json`
- `outputs/graph.png`
- `outputs/nodes/`

## Run The Larger Synthetic Experiment

For a more structured graph-behavior test, run:

```bash
python scripts/run_large_synthetic_experiment.py
```

By default this creates two 200-C-alpha synthetic endpoints, runs recursive
Gaussian sampling from both ends, and falls back to route-constrained waypoint
families if the recursive graph does not produce a 3-4 intermediate path.
Change the size with:

```bash
python scripts/run_large_synthetic_experiment.py --n-residues 500
```

Use `--no-fallback` to inspect the recursive Gaussian result directly even when
it misses the configured 3-4-intermediate target window.

The primary phase still uses `DummyPerturbationGenerator`, but it no longer
samples only from A and B. It starts from both endpoints, generates noisy
children, keeps frontier parents from the closest cross-side A/B candidate
pairs, and repeats up to `recursive_max_iterations`. `n_samples` is the total
accepted recursive-node cap across both sides, while
`recursive_top_k` and `recursive_samples_per_parent` control frontier breadth
and local branching. The fallback creates several candidate waypoint routes and
reports route-family costs so you can see which path wins under the
experiment's squared-RMSD transition score.

For large NetworkX graph views, the experiment config supports sparse display
controls:

```python
graph_min_edge_weight=None
graph_max_edge_weight=None
graph_non_path_edge_alpha=0.125
```

Because edge `weight` is a cost, `graph_max_edge_weight` is usually the most
useful filter: it hides high-cost non-path edges. Path edges are always drawn.

The larger experiment also writes a PyMOL-ready view under
`outputs/large_synthetic/pymol_path/`. Open `view_path.pml` in PyMOL to load A,
B, and the nodes on the selected A-to-B path with distinct colors. If PyMOL is
available locally, the script can also render `path_nodes.png` from inside
PyMOL. Use `--no-pymol` to skip these files.

It also writes `outputs/large_synthetic/py3dmol_path_view.html`, a standalone
3Dmol.js/py3Dmol-style browser view that overlays A, B, and the selected path
nodes. In that view, each colored C-alpha trace is one conformation from the
selected graph path. Larger labeled spheres mark graph-node centroids, and black
cylinders connect consecutive nodes on the best path. In notebooks, call
`display_py3dmol_path(run)` from
`guided_conformational_path.large_synthetic` to show the same structure path
inline next to the NetworkX graph outputs. Use `--no-py3dmol` to skip the HTML
view.

The larger experiment also writes `outputs/large_synthetic/path_morph.gif`, a
Matplotlib-rendered morph animation of the selected best-path C-alpha
backbone. Use `--no-animation` to skip that file, or tune the GIF with
`--animation-frames-per-edge`, `--animation-fps`, and `--animation-dpi`.

## Run Tests

```bash
pytest
```

## BioEmu Colab Bundle Runner

`guided_conformational_path.bioemu_runner.run_bioemu_from_fasta` is a thin
adapter for running BioEmu in environments such as Google Colab. It reads a FASTA
file, requests BioEmu samples, and writes a portable bundle:

- `manifest.json`
- `nodes/*.pdb`
- `raw_bioemu/`

The runner keeps BioEmu imports lazy, so installing this package does not require
BioEmu. The first-five notebook uses the official VS Code Colab extension,
accepts NVIDIA `L4` or `T4` runtimes by policy, and does not use Google Drive.

The official BioEmu output contract uses `topology.pdb` plus `samples.xtc`.
The runner lazily uses BioEmu's `mdtraj` dependency to select C-alpha atoms,
convert XTC coordinates from nanometers to Angstrom, and write one portable
`nodes/*.pdb` file per trajectory frame. Unphysical-sample trajectories are not
imported. Custom samplers may still return PDB paths/text or coordinate arrays.

Because BioEmu APIs can vary across releases and deployments, the runner exposes
`sampler=` as the adapter point. Pass a callable that accepts some subset of
`fasta_path`, `sequence`, `output_dir`, `n_samples`, `num_samples`, and `seed`.
The callable may return PDB paths, PDB text strings, coordinate arrays with shape
`(L, 3)` or `(N, L, 3)`, or write `.pdb` files into the provided output
directory.

BioEmu-generated structures are candidate graph nodes only. They do not by
themselves establish transition dynamics, kinetic connectivity, or free-energy
estimates.

To analyze a completed or downloaded BioEmu bundle locally, keep endpoint files
at:

```text
data/pdb_inputs/A.pdb
data/pdb_inputs/B.pdb
```

Then run:

```bash
UV_CACHE_DIR=.uv-cache uv run python scripts/run_bioemu_precomputed_experiment.py \
  --bioemu-bundle-dir data/bioemu_outputs/latest \
  --outputs-dir outputs/bioemu_experiment
```

The bundle must contain `manifest.json` and normalized generated PDB files
referenced by that manifest. The local analyzer treats BioEmu structures as
neutral `external` graph nodes, then writes the same graph, path, py3Dmol,
PyMOL, and morph-GIF outputs as the synthetic/PDB workflows.

### Dataset Pair To BioEmu Graph Adapter

For endpoint pairs created by `scripts/build_dataset.py`, use the dataset-aware
adapter rather than manually copying endpoints to `data/pdb_inputs/`. The
dataset pair already records the exact BioEmu sequence, aligned endpoint arrays,
and common-residue mapping.

1. In Colab, use the pair's `sequence/bioemu_selected.fasta` as BioEmu input.
2. Download or sync the resulting portable bundle into a local directory such
   as `data/bioemu_outputs/P69441`.
3. Run the adapter and graph analysis in one command:

```bash
uv run python scripts/run_dataset_bioemu_experiment.py \
  --pair-dir data/dataset/first_five_proteins/P69441/pairs/4AKE_A__1AKE_A \
  --bioemu-bundle-dir data/bioemu_outputs/P69441 \
  --outputs-dir outputs/dataset_bioemu/P69441 \
  --k-neighbors 10
```

The adapter performs strict validation before graph construction:

- The BioEmu bundle sequence must exactly equal the dataset pair's selected
  sequence.
- Each BioEmu sample must contain one C-alpha coordinate per selected-sequence
  residue.
- Full-sequence samples are reduced to residues with C-alpha atoms in both
  experimental endpoints, using canonical UniProt positions or construct
  indices from `processed/common_residue_mapping.csv`.
- Adapted samples are rigidly superposed into the aligned endpoint coordinate
  frame. This changes global pose only, not internal conformation or Kabsch-RMSD
  edge costs.
- Missing residue gaps are preserved as residue-position metadata, so validity
  checks do not mistake residues separated by a gap for bonded neighbors.

The command writes the standard `experiment_summary.json`, `path_summary.json`,
`graph.png`, path animation, PyMOL files, and py3Dmol HTML. Add `--write-nodes`
to export the adapted common-residue nodes, or use `--no-animation`,
`--no-pymol`, and `--no-py3dmol` for a faster graph-only run. With 200 samples,
`--k-neighbors 10` is a practical sparse-graph starting point; `0` creates a
fully connected graph.

This residue adapter establishes coordinate correspondence only. It does not
establish that BioEmu samples are kinetically connected to either endpoint.

For the complete no-Drive first-five workflow, first build the upload archive:

```bash
uv run python scripts/colab_transfer.py package-workspace
```

Then open `notebooks/run_bioemu_colab.ipynb`, select **Colab > New Colab Server
> L4** when available, and upload
`outputs/colab_transfers/guided_conformation_workspace.zip` with the extension's
**Upload to Colab** command. The notebook reports the connected GPU and accepts
`L4` plus `T4` by default; it still refuses unsupported GPUs such as A100, CPU,
or TPU runtimes.

The notebook runs a two-sample `P69441 / 4AKE_A__1AKE_A` smoke test first, then
provides one separate 200-sample production cell for each of the five proteins.
Each call performs BioEmu sampling, XTC normalization, dataset-aware graph
construction, and creation of a self-contained result ZIP under
`/content/exports`. Download each ZIP before starting the next protein because
Colab `/content` is ephemeral. BioEmu still has no mid-sample checkpointing, so
each production cell should remain one pair/sample-count task.

Import a downloaded result into the normal local filesystem with:

```bash
uv run python scripts/colab_transfer.py import-result \
  outputs/colab_transfers/downloads/P69441__4AKE_A__1AKE_A__n_200.zip
```

The importer writes the portable bundle under
`data/bioemu_outputs/first_five_proteins/` and graph products under
`outputs/dataset_bioemu/`. Existing runs are not overwritten unless `--force`
is explicit. Google Drive and GitHub cloning are not used by this workflow.

### Parallel BioEmu Workers

The isolated [`parallel_bioemu_tools`](parallel_bioemu_tools/README.md)
subproject prepares deterministic cost-balanced shards, runs one shard per
Colab worker, stores portable bundles in a Hugging Face dataset repository, and
collects verified bundles into the existing local graph pipeline. It imports
the core BioEmu runner, residue adapter, graph experiment, and output writer
rather than duplicating them.

The parallel Colab notebook uploads a completion marker only after all bundle
files are remotely visible. It then releases the managed runtime automatically;
any generation or upload failure keeps the runtime attached for recovery. If a
T4 runtime disappears after the final marker is visible, a newly assigned
runtime can reuse that marker and skip the completed shard task. If the runtime
dies earlier, rerunning the same immutable shard safely retries the bundle
upload/generation because incomplete prefixes are never treated as complete.
Live parallel execution remains separate from the current serial five-protein
test.

## Plugging In New Generators Later

Future ensemble generators should implement the `NodeGenerator` interface:

```python
class NodeGenerator:
    def generate_from_endpoint(self, endpoint, n_samples, **kwargs):
        ...
```

The package already includes placeholder `BioEmuNodeGenerator` and
`EigenFoldNodeGenerator` classes. A future implementation should call the
external model, convert generated structures into C-alpha coordinate arrays, and
return `ConformationNode` objects. The graph, scoring, validity, visualization,
and path-search layers should not need to know which generator produced the
nodes.

The dummy Gaussian generator may return fewer than the requested number of nodes
if validity filtering rejects too many proposed samples within its attempt
budget. The generator records accepted/rejected counts in
`last_generation_summary` and in accepted node metadata.

## Checkpoint And Resume

The general project-level `--resume` interface is still limited, but the
parallel BioEmu worker path now has durable shard resume semantics:

- Each task writes to an immutable `run_id/protein_id/pair_id/n_<samples>`
  prefix.
- The worker uploads `_worker_completed.json` only after the bundle manifest and
  all regular files are remotely visible in Hugging Face.
- A newly assigned runtime can download that marker and skip regenerating an
  already durable task, even if the previous Colab VM was reclaimed.

This is task-level resume, not mid-sample checkpointing. BioEmu itself still
cannot resume halfway through a partially generated sample batch.
