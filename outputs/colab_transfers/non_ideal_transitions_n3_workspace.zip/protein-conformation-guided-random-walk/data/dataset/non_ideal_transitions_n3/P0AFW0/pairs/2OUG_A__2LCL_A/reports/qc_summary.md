# Endpoint Pair QC: 2OUG_A__2LCL_A

Status: **manual_review**

- Sequence identity: 1.0000
- Aligned coverage: 1.0000
- Common C-alpha atoms: 42
- Aligned C-alpha RMSD: 10.821011297922468
- Candidate selection score: 0.0000
- BioEmu sequence source: construct

## Warnings

- Source organisms differ
- Missing-residue fractions differ substantially and may distort RMSD
- One endpoint is NMR and the other uses a different experimental method
- Deposited protein-chain counts/oligomeric states differ
- Protein-binding partner chains differ between endpoints
- At least one endpoint contains multiple experimental models

## Rejection Reasons

- None

## Sequence Selection Warnings

- Using shared endpoint construct rather than the canonical UniProt sequence

## Scientific Caveat

Multiple experimental structures do not prove a direct transition pathway. Equilibrium
accessibility does not imply kinetic connectivity. Ligands, mutations, truncations,
oligomeric changes, and missing residues can all produce structural differences. This
report identifies a candidate endpoint pair plus QC evidence, not ground truth.

## Domain Selection

- Mode: `shared_domain_from_b`
- Selected residues: 62
- Caveat: Endpoint A was trimmed to the sequence-aligned domain represented by endpoint B; this is a domain-only comparison, not a full-protein transition.


