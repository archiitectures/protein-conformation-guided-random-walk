# Endpoint Pair QC: 2QKE_A__5JYT_A

Status: **manual_review**

- Sequence identity: 1.0000
- Aligned coverage: 1.0000
- Common C-alpha atoms: 93
- Aligned C-alpha RMSD: 9.029142327426104
- Candidate selection score: 0.0000
- BioEmu sequence source: canonical

## Warnings

- Source organisms differ
- Detected 1 sequence mismatch/mutation annotation(s)
- One endpoint is NMR and the other uses a different experimental method
- Deposited protein-chain counts/oligomeric states differ
- Protein-binding partner chains differ between endpoints
- At least one endpoint contains multiple experimental models

## Rejection Reasons

- None

## Sequence Selection Warnings

- Using the canonical sequence while graph coordinates are restricted to exact endpoint matches from a mutation-stabilized construct

## Scientific Caveat

Multiple experimental structures do not prove a direct transition pathway. Equilibrium
accessibility does not imply kinetic connectivity. Ligands, mutations, truncations,
oligomeric changes, and missing residues can all produce structural differences. This
report identifies a candidate endpoint pair plus QC evidence, not ground truth.


## Residue Selection

- Mode: `shared_exact_matches`
- Selected residues: 96
- Caveat: Only exact sequence matches between endpoints are compared; BioEmu samples use the canonical sequence and the mutation-stabilized endpoint remains a manual-review case.

