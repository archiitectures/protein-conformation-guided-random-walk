# Endpoint Pair QC: 1DUJ_A__1S2H_A

Status: **manual_review**

- Sequence identity: 0.9893
- Aligned coverage: 0.9078
- Common C-alpha atoms: 186
- Aligned C-alpha RMSD: 10.39440998398673
- Candidate selection score: 0.0000
- BioEmu sequence source: canonical

## Warnings

- Detected 3 sequence mismatch/mutation annotation(s)
- Endpoint chain lengths differ by 19 residues

## Rejection Reasons

- None

## Sequence Selection Warnings

- None

## Scientific Caveat

Multiple experimental structures do not prove a direct transition pathway. Equilibrium
accessibility does not imply kinetic connectivity. Ligands, mutations, truncations,
oligomeric changes, and missing residues can all produce structural differences. This
report identifies a candidate endpoint pair plus QC evidence, not ground truth.


